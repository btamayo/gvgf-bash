def start():
    print "Start!"
