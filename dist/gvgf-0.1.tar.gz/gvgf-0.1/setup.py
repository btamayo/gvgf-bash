from setuptools import setup

setup(name='gvgf',
      version='0.1',
      description='gvgf',
      url='http://github.com/btamayo/gvgf',
      author='Bianca Tamayo',
      author_email='hi@biancatamayo.me',
      license='MIT',
      packages=['gvgf'],
      zip_safe=False)